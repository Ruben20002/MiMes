package com.example.proyectofindecurso;

import static com.example.proyectofindecurso.CalendarUtils.daysInMonthArray;
import static com.example.proyectofindecurso.CalendarUtils.monthYearFromDate;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdaptadorCalendario.OnItemListener{
    private TextView mesAñotext;
    private RecyclerView calendarioRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initWidgets();
        CalendarUtils.selectedDate = LocalDate.now();
        setMonthView();

    }
    private void initWidgets() {
        calendarioRecyclerView = findViewById(R.id.calendariosRecyclerView);
        mesAñotext = findViewById(R.id.mesdelano);
    }

    private void setMonthView() {
        mesAñotext.setText(monthYearFromDate(CalendarUtils.selectedDate));
        ArrayList<LocalDate> daysInMonth = daysInMonthArray(CalendarUtils.selectedDate);

        AdaptadorCalendario adaptadorCalendario = new AdaptadorCalendario(daysInMonth,this);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getApplicationContext(),7);
        calendarioRecyclerView.setLayoutManager(layoutManager);
        calendarioRecyclerView.setAdapter(adaptadorCalendario);
    }




    public void mesanterior(View view) {
        CalendarUtils.selectedDate =  CalendarUtils.selectedDate.minusMonths(1);
        setMonthView();

    }

    public void messiguiente(View view) {
        CalendarUtils.selectedDate =  CalendarUtils.selectedDate.plusMonths(1);
        setMonthView();
    }

    @Override
    public void onItemClick(int position, LocalDate date) {
            if (date != null) {


                CalendarUtils.selectedDate = date;
                setMonthView();
            }
    }
    public void weeklyAction(View view) {
        startActivity(new Intent(this, VistaSemanal.class));
    }
}