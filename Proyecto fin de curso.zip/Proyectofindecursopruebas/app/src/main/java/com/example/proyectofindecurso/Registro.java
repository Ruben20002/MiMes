package com.example.proyectofindecurso;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Registro extends AppCompatActivity {

    String email;
    String password;
    String password2;

    String regex = "^[A-Za-z0-9+_.-]+@(.+)$";
    Pattern pattern = Pattern.compile(regex);

    FirebaseAuth mAuth;
    FirebaseUser mUser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        mAuth=FirebaseAuth.getInstance();
        mUser=mAuth.getCurrentUser();
    }
    public void registro(View view){

        EditText emailE = findViewById(R.id.CorreoText);
        EditText passwordE = findViewById(R.id.passwordText1);
        EditText passwordE2 = findViewById(R.id.passwordText2);


        email = emailE.getText().toString();
        password = passwordE.getText().toString();
        password2 = passwordE2.getText().toString();

        Matcher matcher = pattern.matcher(email);


        if (!matcher.matches()){

        } else if (password.isEmpty() || password.length()<6){

        }  else {
            mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){

                    } else {

                    }
                }
            });

            Intent siguiente = new Intent(this, MainActivity.class);
            startActivity(siguiente);

        }

    }
}